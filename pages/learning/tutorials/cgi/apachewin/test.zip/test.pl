#!/perl/bin/perl -w
print "Content-type: text/html\n\n";
print "This CGI script works!";